<?php
//$random = random_bytes(15);
//echo bin2hex($random);

$activation_link = bin2hex(random_bytes(15));
